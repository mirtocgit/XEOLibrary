/*Enconding=UTF-8*/
package netgest.bo.plugins.data;

public class MapType2SyncTextIndex 
{
    public MapType2SyncTextIndex()
    {
    }
}