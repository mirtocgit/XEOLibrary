/*Enconding=UTF-8*/

// Copyright (c) 2001 IIES
package netgest.bo.parser.symbol;

public interface ClauseDeclarationSymbol extends Symbol {
}
