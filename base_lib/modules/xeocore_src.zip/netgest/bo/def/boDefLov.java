/*Enconding=UTF-8*/
package netgest.bo.def;
import netgest.utils.ngtXMLHandler;

/**
 * 
 * @Company Enlace3
 * @author Francisco Luís Brinó Câmara
 * @version 1.0
 * @since 
 */
 
public interface boDefLov
{
    public ngtXMLHandler[] getLovs();

    public ngtXMLHandler[] getChilds();
   
}