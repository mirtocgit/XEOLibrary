package netgest.bo.def;

public interface boDefObjectFilter 
{
    public String       getForObject();
    public String       getXeoQL();
    public boDefXeoCode getCondition();
    
}