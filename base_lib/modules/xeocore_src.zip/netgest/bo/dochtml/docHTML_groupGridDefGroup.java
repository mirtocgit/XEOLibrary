/*Enconding=UTF-8*/
package netgest.bo.dochtml;
import java.util.*;


public final class docHTML_groupGridDefGroup 
{
    
    public String p_boql;
    public String p_title;
    public Hashtable p_attributes;
    
    public docHTML_groupGridDefGroup(String boql,String title, Hashtable attributes)
    {
        p_boql=boql;
        p_title=title;
        p_attributes=attributes;
    }
    
}