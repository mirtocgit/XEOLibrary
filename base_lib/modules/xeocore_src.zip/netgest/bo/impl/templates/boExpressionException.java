/*Enconding=UTF-8*/
package netgest.bo.impl.templates;
import netgest.bo.runtime.boAttributesArray;

/**
 * 
 * @Company Enlace3
 * @author João Paulo Trindade Carreira
 * @version 1.0
 */
public class boExpressionException extends Exception
{
    public boExpressionException(String message)
    {
        super(message);
    }
}