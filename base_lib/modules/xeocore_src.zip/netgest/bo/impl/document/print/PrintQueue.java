package netgest.bo.impl.document.print;
import java.io.File;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Vector;
import netgest.bo.runtime.EboContext;
import netgest.bo.runtime.boObject;
import netgest.bo.runtime.boObjectList;
import netgest.bo.runtime.boRuntimeException;
import netgest.utils.StringUtils;

public class PrintQueue 
{

    
    

    
}