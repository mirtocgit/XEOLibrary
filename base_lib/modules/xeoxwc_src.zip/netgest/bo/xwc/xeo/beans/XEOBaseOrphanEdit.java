package netgest.bo.xwc.xeo.beans;

@Deprecated			
public class XEOBaseOrphanEdit extends XEOEditBean {

}
