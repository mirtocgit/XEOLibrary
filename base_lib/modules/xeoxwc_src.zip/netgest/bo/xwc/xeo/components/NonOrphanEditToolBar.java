package netgest.bo.xwc.xeo.components;

@Deprecated
public class NonOrphanEditToolBar extends EditToolBar {
}
