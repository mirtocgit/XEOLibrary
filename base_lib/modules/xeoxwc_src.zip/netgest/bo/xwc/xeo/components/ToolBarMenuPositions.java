package netgest.bo.xwc.xeo.components;

import netgest.bo.xwc.components.classic.ToolBar;

public class ToolBarMenuPositions extends ToolBar {

	protected int	currentMenuPos = 0;
	
}
