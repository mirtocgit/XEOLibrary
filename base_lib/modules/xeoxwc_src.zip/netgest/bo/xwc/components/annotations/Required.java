/**
 * 
 */
package netgest.bo.xwc.components.annotations;

/**
 * 
 * Components annotation to mark a property as required
 * only when using a given component directly
 * 
 * @author PedroRio
 *
 */
public @interface Required {

}
