package netgest.bo.xwc.components.connectors;

import netgest.bo.runtime.AttributeHandler;

public class XEOBridgeFieldConnector extends XEOObjectAttributeConnector {

    public XEOBridgeFieldConnector( XEOObjectConnector oConnector, AttributeHandler oAttHandler ) {
        super( oConnector, oAttHandler );
    }

}
