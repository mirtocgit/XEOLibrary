package netgest.bo.xwc.components.beans;

@Deprecated
public class XEOBaseOrphanEdit extends netgest.bo.xwc.xeo.beans.XEOBaseOrphanEdit 
{
}
