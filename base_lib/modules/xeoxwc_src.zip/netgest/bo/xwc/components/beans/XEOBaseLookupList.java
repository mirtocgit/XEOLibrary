package netgest.bo.xwc.components.beans;


@Deprecated
public class XEOBaseLookupList extends netgest.bo.xwc.xeo.beans.XEOBaseLookupList {
	
}
