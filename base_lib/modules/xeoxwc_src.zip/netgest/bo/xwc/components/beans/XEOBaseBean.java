package netgest.bo.xwc.components.beans;

@Deprecated
public class XEOBaseBean extends netgest.bo.xwc.xeo.beans.XEOEditBean {

}
