package netgest.bo.xwc.components.classic.renderers;

import netgest.bo.xwc.framework.XUIRenderer;

public class XMLSkipRenderer extends XUIRenderer {

}
