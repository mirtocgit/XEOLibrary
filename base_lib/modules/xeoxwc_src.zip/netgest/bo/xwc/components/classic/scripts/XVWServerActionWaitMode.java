package netgest.bo.xwc.components.classic.scripts;

public enum XVWServerActionWaitMode {
	NONE,
	DIALOG,
	STATUS_MESSAGE
}
