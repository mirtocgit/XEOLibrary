package netgest.bo.xwc.components.explorer;

public class XUIUserPreferences {
	
	
	
}
